KVA Software DoHide version 3.0
-------------------------------

To Install DoHide

   1. Create a folder for DoHide ( such as C:\Program Files\DoHide )
   2. Unzip file DoHide30.zip to this folder
   3. Run DoHide.exe


Visit the KVA Software Web Site at 
   http://www.uran.net/kva
   kirienko@geocities.com
   kva@uran.net


Copyright (C) 1996-1999, KVA Software, Vladimir Kirienko. All rights reserved.

