KVA software DoHide version 2.3
-------------------------------

To Install DoHide

   1. Create a folder for DoHide ( such as C:\Program Files\DoHide )
   2. Unzip file DoHide23.zip to this folder
   3. Run DoHide.exe


Visit the KVA software Web Site at 
   http://www.uran.net/kva
   kirienko@geocities.com



(C) Copyright 1996-1999, KVA software, Vladimir Kirienko. All rights reserved.

