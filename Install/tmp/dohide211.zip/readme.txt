KVA software DoHide version 2.11
--------------------------------

To Install DoHide

   1. Create a folder for DoHide ( such as C:\Program Files\DoHide )
   2. Unzip file DoHide211.zip to this folder
   3. Run DoHide.exe


Visit the KVA software Web Site at 
   http://www.geocities.com/SiliconValley/Way/5573
   kirienko@geocities.com



(C) Copyright 1996-1998, KVA software, Vladimir Kirienko. All rights reserved.

