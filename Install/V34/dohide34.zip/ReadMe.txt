KVA Software DoHide version 3.4
-------------------------------

To Install DoHide

   1. Create a folder for DoHide ( such as C:\Program Files\DoHide )
   2. Unzip file DoHide34.zip to this folder
   3. Run DoHide.exe


Visit the KVA Software Web Site at 
   http://kva.no-ip.com/DoHide
   vkirienko@yahoo.com


Copyright (C) 1996-2004, KVA Software, Vladimir Kirienko. All rights reserved.

